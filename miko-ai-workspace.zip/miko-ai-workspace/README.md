# miko-ai-workspace

Personal AI developer workspace for experimenting with LLM applications, cloud computing, GitHub workflows, and GPU-based AI workloads.

## Focus Areas

- Large Language Models (LLM)
- AI inference workflows
- Cloud computing
- GPU-based workloads
- Git and GitHub practice
- Data analysis experiments

## Projects Included

This repository contains simple starter scripts for AI workflow experiments:

- `app.py` - simple AI project entry point
- `inference_demo.py` - basic prompt/inference workflow demo
- `gpu_notes.md` - notes about cloud GPU and ROCm learning
- `requirements.txt` - Python dependencies

## Goal

The goal of this repository is to document learning progress while building AI applications and experimenting with cloud GPU environments.

## Status

Early-stage personal learning and research project.
